<html>
    <head>
    <!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>BookMyShow</title>
    <meta name="description" content="Ela Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!--<link rel="apple-touch-icon" href="images/favicon.png">
    <link rel="shortcut icon" href="images/favicon.png"> -->

    <link rel="stylesheet" href="assets/css/normalize.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
<link rel="stylesheet" href="assets/css/pe-icon-7-filled.css">
    <link rel="stylesheet" href="assets/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <!-- <link rel="stylesheet" href="assets/css/bootstrap-select.less"> -->
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.7.0/css/all.css' integrity='sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ' crossorigin='anonymous'>

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
    <script src="//cdnjs.cloudflare.com/ajax/libs/dat-gui/0.5/dat.gui.min.js" type="text/javascript"></script>

        <style>
            .transition,
form button,
form .question label,
form .question input[type="text"] {
-moz-transition: all 0.25s cubic-bezier(0.53, 0.01, 0.35, 1.5);
-o-transition: all 0.25s cubic-bezier(0.53, 0.01, 0.35, 1.5);
-webkit-transition: all 0.25s cubic-bezier(0.53, 0.01, 0.35, 1.5);
transition: all 0.25s cubic-bezier(0.53, 0.01, 0.35, 1.5);
}

    * {
font-family: 'Montserrat', sans-serif;;
font-weight: light;
-webkit-font-smoothing: antialiased;
}
body{
    background-image:url('/bookmyshow/images/red3.jpg');
    background-size:cover;
}

form .page{
    border:2px solid black;
}


form h1 {
color: #007bff;
font-weight: 100;
letter-spacing: 0.01em;
margin-left: 15px;
margin-bottom: 35px;
text-transform: uppercase;
}

form button {
margin-top: 10px;
background-color: white;
border: 1px solid black;
line-height: 0;
font-size: 17px;
display: inline-block;
box-sizing: border-box;
padding: 16px 25px;
border-radius: 50px;

font-weight: 100;
letter-spacing: 0.01em;
position: relative;
z-index: 1;
}

form button:hover,
form button:focus {
color: white;
background-color:#F33652;
}

form .question {
position: relative;
padding: 10px 0;
}

form .question:first-of-type {
padding-top: 0;
}

form .question:last-of-type {
padding-bottom: 0;
}

form .question label {
transform-origin: left center;

font-weight: 100;
letter-spacing: 0.01em;
font-size: 17px;
box-sizing: border-box;
padding: 10px 15px;
display: block;
position: absolute;
margin-top: -40px;
z-index: 2;
pointer-events: none;
}

form .question input[type="text"] {
appearance: none;
background-color: none;
border: 1px solid black;
line-height: 0;
font-size: 17px;
width: 100%;
display: block;
box-sizing: border-box;
padding: 10px 15px;
border-radius: 60px;

font-weight: 100;
letter-spacing: 0.01em;
position: relative;
z-index: 1;
}

form .question input[type="text"]:focus {
outline: none;
background:#F33652;
color: white;
margin-top: 30px;
}
form .question input[type="text"]:valid {
margin-top: 30px;
}

form .question input[type="text"]:focus ~ label {
-moz-transform: translate(0, -35px);
-ms-transform: translate(0, -35px);
-webkit-transform: translate(0, -35px);
transform: translate(0, -35px);
}
form .question input[type="text"]:valid ~ label {
text-transform: uppercase;
font-style: italic;
-moz-transform: translate(5px, -35px) scale(0.6);
-ms-transform: translate(5px, -35px) scale(0.6);
-webkit-transform: translate(5px, -35px) scale(0.6);
transform: translate(5px, -35px) scale(0.6);}

.radio {
 

position: relative;
padding-left: 90px;
margin-bottom: 12px;
cursor: pointer;
font-size: 20px;
-webkit-user-select: none;
-moz-user-select: none;
-ms-user-select: none;
user-select: none;


}

/* Hide the browser's default radio button */
.radio input {
position: absolute;
opacity: 0;
cursor: pointer;

}
/* Create a custom radio button */
.checkround {

position: absolute;
top: 6px;
left: 60px;
height: 20px;
width: 20px;
background-color: #fff ;

border-style:solid;
border-width:2px;
 border-radius: 50%;
}


/* When the radio button is checked, add a blue background */
.radio input:checked ~ .checkround {
background-color: #fff;
}

/* Create the indicator (the dot/circle - hidden when not checked) */
.checkround:after {
content: "";
position: absolute;
display: none;
}

/* Show the indicator (dot/circle) when checked */
.radio input:checked ~ .checkround:after {
display: block;
}

/* Style the indicator (dot/circle) */
.radio .checkround:after {
 left: 2px;
top: 2px;
width: 12px;
height: 12px;
border-radius: 50%;
background:#F33652;


}
h2{
  color:#F33652;
  margin-left:40%;
}


	canvas {
		display: block;
	}
	.title {
		color: #FFF;
		position: absolute;
		top: 8px;
		left: 12px;
		font-family: verdana;
		text-transform: uppercase;
		font-size: 10px;
		font-weight: bold;
	}
</style>

<body>
<div class="sufee-login d-flex align-content-center flex-wrap">

   <div class="container">


       <div class="login-content">
           <div class="login-logo">
               <a href="index.html">
                  
               </a>
           </div>
           <div class="login-form">
          
           <form action="" method="post" class="page">
         
                 <div class="form-group"> 
                    
                  <h2>Login</h2>
                      <label class="radio ">Admin
                      <input type="radio" class="form-control" checked="checked" name="is_company">
                         <span class="checkround"></span>
                     </label>
                     <label class="radio">Sub-Admin
                      <input type="radio" class="form-control"  name="is_company">
                         <span class="checkround"></span>
                     </label><br>
                 </div>  

                 <div class="form-group question ">    
                    <input type="text"  class="form-control" required/>
                    <label><i class='fas fa-user' style='font-size:20px '></i>&nbsp;Username</label>
                 </div>
                 <div class="form-group question "> 
                   <input type="text"  class="form-control" required/>
                     <label><i class="fa fa-lock" style="font-size:20px"></i>&nbsp;Password</label>
                 </div>
               <center> 
                 <div>
                   <button type="submit" name="submit" class="form button">Submit</button>
                 </div><center>
              </form>
           </div>
       </div>
   </div>
</div>

</div>



</body>

</html>
<canvas id="canvas"></canvas>

<script src="//cdnjs.cloudflare.com/ajax/libs/dat-gui/0.5/dat.gui.min.js" type="text/javascript"></script>
<script>
   var requestAnimationFrame = window.requestAnimationFrame || window.mozRequestAnimationFrame ||
    window.webkitRequestAnimationFrame || window.msRequestAnimationFrame;

var cancelAnimationFrame = window.cancelAnimationFrame || window.mozCancelAnimationFrame;

var rAF;


var canvas = document.getElementById("canvas"),
    context = canvas.getContext("2d"),
    width = canvas.width = window.innerWidth,
    height = canvas.height = window.innerHeight,
    particles = [],
    mouseX = 0,
    mouseY = 0,
    total = 15,
    followSpeed = 0.1,
    size = 25;

document.body.addEventListener("mousemove", function (event) {
    mouseX = event.clientX;
    mouseY = event.clientY;
});

window.addEventListener('resize', function () {
    width = canvas.width = window.innerWidth;
    height = canvas.height = window.innerHeight;
});

function init() {
    cancelAnimationFrame(rAF);

    particles = [];

    for (var i = 0; i < total; i += 1) {
        particles.push(new Particle(i));
    }

    draw();
}

function draw() {
    context.clearRect(0, 0, width, height);

    for (var i = 0; i < total; i += 1) {
        particles[i].update();
    }

    rAF = requestAnimationFrame(draw);
}


/**
 * Particle
 */
var Particle, p;

Particle = function (index) {
    this.initialize(index);
};

p = Particle.prototype;

p.initialize = function (index) {
    this.x = -50;
    this.y = height;
    this.id = index + 1;
    this.angleX = Math.PI * 2 * Math.random();
    this.angleY = Math.PI * 2 * Math.random();
    this.speedX = .03 * Math.random() + .03;
    this.speedY = .03 * Math.random() + .03;
    this.radius = 150;

    return this;
};

p.update = function () {
    var aim, dx, dy, scale, angle;

    if (this.id > 1) {
        aim = particles[this.id - 1 - 1];
        dx = aim.x - this.x;
        dy = aim.y - this.y;

        this.x += dx * con.speed;
        this.y += dy * con.speed;
    } else {
        if (mouseX === 0 && mouseY === 0) {
            dx = width / 2 + Math.cos(this.angleX) * this.radius - this.x;
            dy = height / 2 + Math.sin(this.angleY) * this.radius - this.y;

            this.x = width / 2 + Math.cos(this.angleX) * this.radius;
            this.y = height / 2 + Math.sin(this.angleY) * this.radius;

            this.angleX += this.speedX;
            this.angleY += this.speedY;

        } else {
            dx = mouseX - this.x;
            dy = mouseY - this.y;

            this.x += dx * con.speed;
            this.y += dy * con.speed;
        }
    }

    angle = Math.atan2(dy, dx);
    scale = Math.cos(Math.PI / 2 * (this.id / total));

    context.save();
    context.translate(this.x, this.y);
    context.rotate(angle);
    context.scale(scale, scale);

    context.beginPath();
    context.moveTo(-size / 2 * 1.732, -size / 2);
    context.lineTo(0, 0);
    context.lineTo(-size / 2 * 1.732, size / 2);
    context.lineTo(-size / 2 * 1.2, 0);
    context.fillStyle = 'white';
    context.fill();

    context.restore();
};

// control bar
var ControlBar = function () {
    this.num = total;
    this.speed = followSpeed;
};

var con = new ControlBar();
var gui = new dat.GUI();
var conSpeed = gui.add(con, 'speed', 0.05, 0.25).step(0.05);
var conNum = gui.add(con, 'num', 10, 30).step(1);

conNum.onFinishChange(function (value) {
    total = value;

    init();
});

init();



    </script>
