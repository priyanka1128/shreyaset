<?php
include_once("db.php");
//Checking if any error occured while connecting
	if (mysqli_connect_errno()) {
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
		die();
	}
	$mobile=$_POST['mobile'];
	$isuserExists=mysqli_query($con,"select * from users where mobile='$mobile'");
	$data = array();
	if ($isuserExists) {
	    
	    //generate otp
	        $otp = rand(100000, 999999);
            while($row=mysqli_fetch_array($isuserExists)){
            $user_id=$row['id'];
            $sms_code=mysqli_query($con,"insert into sms_codes(user_id,code,status) values ('$user_id','$otp',1)");
            if($sms_code){
                sendSms($mobile, $otp);
                
                $temp['otp'] = $otp;
     	        array_push($data, $temp);
     	        echo json_encode($data);
                }
            } 
	}

	function sendSms($mobile, $otp) {
 
    //Your message to send, Add URL encoding here.
    $message = urlencode("Hello! Welcome To Shreyas. Your Login OPT is : ".$otp);
 
    $response_type = 'json';
 
    //Define route 
    $route = "4";
     
    //Prepare you post parameters
    $postData = array(
        'authkey' => MSG91_AUTH_KEY,
        'mobiles' => $mobile,
        'message' => $message,
        'sender' => MSG91_SENDER_ID,
        'route' => $route,
        'response' => $response_type
    );
 
//API URL
    $url = "https://control.msg91.com/sendhttp.php";
 
// init the resource
    $ch = curl_init();
    curl_setopt_array($ch, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $postData
            //,CURLOPT_FOLLOWLOCATION => true
    ));
 
 
    //Ignore SSL certificate verification
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
 
 
    //get response
    $output = curl_exec($ch);
 
    //Print error if any
    if (curl_errno($ch)) {
        echo 'error:' . curl_error($ch);
    }
 
    curl_close($ch);
}
?>