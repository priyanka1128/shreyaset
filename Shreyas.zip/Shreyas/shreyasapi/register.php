<?php
include_once("db.php");
    $f_name=$_POST['f_name'];
    $l_name=$_POST['l_name'];
    $dob=$_POST['dob'];
	$mobile=$_POST['mobile'];
	$email=$_POST['email'];
	$gender=$_POST['gender'];
	$fan_of=$_POST['fan_of'];
	$pic=$_POST['pic'];
	//$ImageName = $_POST['imagename'];
    $ImagePath = "uploads/$pic.jpg";
 
    $ServerURL = "http://minetechsoftwares.com/Shreyas/shreyasapi/$ImagePath";
	$isUserExists=mysqli_query($con,"select * from users where mobile='$mobile'");

    $row=mysqli_fetch_array($isUserExists);
    $mobile1=$row['mobile'];
    
	$data = array();
	if ($mobile==$mobile1) {
	    echo "user already exists";
	}else{
	    //generate otp
	        $otp = rand(100000, 999999);
	        echo $otp;
            $users=mysqli_query($con,"INSERT INTO `users`(`f_name`, `l_name`, `dob`, `mobile`, `email`, `gender`, `fan_of`, `pic`, `status`)
            VALUES ('$f_name','$l_name','$dob','$mobile','$email','$gender','$fan_of','$ServerURL',1)");
            if($users){
                sendSms($mobile, $otp);
                
                $temp['otp'] = $otp;
     	        array_push($data, $temp);
     	        echo json_encode($data);
                }
        
	}

	function sendSms($mobile, $otp) {
 
    //Your message to send, Add URL encoding here.
    $message = urlencode("Hello! Welcome To Shreyas. Your First Time Registration OPT is : ".$otp);
 
    $response_type = 'json';
 
    //Define route 
    $route = "4";
     
    //Prepare you post parameters
    $postData = array(
        'authkey' => MSG91_AUTH_KEY,
        'mobiles' => $mobile,
        'message' => $message,
        'sender' => MSG91_SENDER_ID,
        'route' => $route,
        'response' => $response_type
    );
 
//API URL
    $url = "https://control.msg91.com/sendhttp.php";
 
// init the resource
    $ch = curl_init();
    curl_setopt_array($ch, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $postData
            //,CURLOPT_FOLLOWLOCATION => true
    ));
 
 
    //Ignore SSL certificate verification
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
 
 
    //get response
    $output = curl_exec($ch);
 
    //Print error if any
    if (curl_errno($ch)) {
        echo 'error:' . curl_error($ch);
    }
 
    curl_close($ch);
}
?>