<?php
include('header.php');
include('connection.php');

if(isset($_GET['delet'])){



$id=$_GET['delet'];
$update_query = "UPDATE users SET status =1 WHERE id='$id'";
$query= mysqli_query($db, $update_query);

if($query)
{
echo "<script>alert(' Deleted info Successfully........!');
window.location='event_checkin.php';
</script>";
} 


}

?>

<?php
if(isset($_GET['approve']))

{
  $id=$_GET['approve'];

	$status="Approved";


	
	 $query="UPDATE users SET current_status='$status' where id='$id'";
	
	$res=mysqli_query($db,$query);

	if($res){
	echo "<script>alert(' User Approved Successfully........!');
            window.location='event_checkin.php';
                      </script>";
		
	}

}
if(isset($_GET['reject']))
{
     $id=$_GET['reject'];
	$status= "Rejected";
   
	
	$query="UPDATE `users` set `current_status`='$status' where `id`='$id'";
	
	$res=mysqli_query($db,$query);
	
	if($res){
	    
	echo "<script>alert(' User Rejected Successfully........!');
            window.location='event_checkin.php';
                      </script>";
		
	}
	
}


?>

<div class="breadcrumbs">
        <div class="breadcrumbs-inner">
            <div class="row m-0">
                <div class="col-sm-4">
                    <div class="page-header float-left">
                        
                    </div>
                </div>
                    <div class="col-sm-8">
                        <div class="page-header float-right">
                            <div class="page-title">
                                <ol class="breadcrumb text-right">
                                    <li><a href="#">Dashboard</a></li>
                                    <li><a href="#">Events</a></li>
                                    <li class="active">Event Check In</li>
                                </ol>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
</div>

        <div class="content pb-0"> 
            <div class="card">
                <div class="card-header">
                    <strong class="card-title">Event Check in</strong>
                </div>
                    <div class="card-body">
                        <table id="bootstrap-data-table" class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                            <th>Id</th>
                                            <th>First Name</th>
                                            <th>Last Name</th>
                                             
                                             <th>Current Status</th>
                                           <th>Status</th>
                                            <th>Action</th>
                                            
                                            </tr>
                                        </thead>
                                </div> 
                        </div>

                                    <tbody>
                                                <?php
                                                $sql = ("SELECT id, f_name, l_name, current_status FROM users WHERE status=0");
                                                
                                                $result=mysqli_query($db,$sql)or die(mysqli_error($db));
                                                while($row=mysqli_fetch_array($result)) 
                                                { 
                                                ?>
                                                
                                                <tr><td data-title="id"><?php echo $row["id"];?></td>
                                                <td data-title="f_name"><?php echo $row["f_name"]; ?></td>
                                                <td data-title="l_name"><?php echo $row["l_name"]; ?></td>
                                                
                                                  <td data-title="status"style="color:blue"><?php echo $row["current_status"];?></td>
                                                <td> <a href="event_checkin.php?approve=<?php echo $row["id"]; ?>"<i class="fa fa-check-square" style="color:green"></i>Approve</a>&nbsp;&nbsp;&nbsp;                                             <a href="event_checkin.php?reject=<?php echo $row["id"]; ?>"<i class="fa fa-times-circle"style="color:red"></i>Reject</a> </td>
                                              
                                            
                                                
                                                
                                              
                                           
                                             
                                              <td><a href="event_checkin.php?delet=<?php echo $row["id"]; ?>"><i class="fa fa-trash" style="width:20px;color:#ec2d5d;"></i></a>
                                              
                                              </td>
                                                </tr>
                                                <?php } ?>
                                    </tbody>

                        </table>
            </div>

        </div> 
                    <?php
                    include('footer.php');
                    ?>
                    <script type="text/javascript">
                    $(document).ready(function() {
                    $('#bootstrap-data-table-export').DataTable();
                    } );
                    </script>