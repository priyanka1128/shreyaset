<?php

$db = mysqli_connect('localhost', 'rahuldemo_showbooking', 'showbooking', 'rahuldemo_db_showbooking');
if($db->connect_errno){
	die('Sorry Database not connected !!!');
}

?>