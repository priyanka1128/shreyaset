<!----------------include header file----------------------->
<?php
include('connection.php');
include('header.php');
session_start();
if($_SESSION["username"]==true)
{
 
}
else
{
	 header('location:index.php');
}

?>

<?php
if (isset($_GET['edit']))
	{
		$id = $_GET['edit'];

		$record = mysqli_query($db,"SELECT * FROM events  WHERE id='$id'") or die(mysqli_error($db));
			if ($n = mysqli_fetch_array($record))
		
			{
			                       $eventtype=$n['type'];
                                   $eventname=$n['name'];
                                   $image=$n['poster'];
                                    $starname=$n['starcast'];
			                  	  $vlink=$n['videolink'];
	                              $lang=$n['language'];
	                           $dimention=$n['dimentions'];
                                  	 $stime=$n['start_time'];
                                  $etime=$n['end_time'];

			}
		
	  

                        if (isset($_POST['update'])) {
                      
                                $eventtype=$_POST['eventtype'];
                                $eventname=$_POST['eventname'];
                              $stime=$_POST['stime'];
                               $etime=$_POST['etime'];
                             $starname=$_POST['starname'];
                             	
                    	 $vlink=$_POST['vlink'];
	                $lang=$_POST['language'];
	               $dimention=$_POST['dimention'];
	  
                             
                    	$target_dir = "uploads/";
	$target_file = $target_dir . basename($_FILES["image"]["name"]);
		$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
		
		if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)){
			echo "The file ". basename( $_FILES["image"]["name"]). " has been uploaded.";
			} else {
			echo "Sorry, there was an error uploading your file.";
		}
		
	$image="https://www.minetechsoftwares.com/Shreyas/uploads/".$_FILES["image"]["name"];

        $id = $_GET['edit'];
        
		$query1=mysqli_query($db,"UPDATE events SET type='$eventtype',name='$eventname',start_time='$stime',end_time='$etime',starcast='$starname', poster='$image', videolink='$vlink', language='$lang',dimentions='$dimention' WHERE id='$id'");
        $result = mysqli_query($db,$query);
		
		 if($query1)
        {
			echo "<script>alert('  Event  Updated successfully........!');
			window.location='add_evnt.php';
			</script>";
        }	
		}  
	}
?>


<!----------------------sub-navbar--------------------------->
   <div class="breadcrumbs">
        <div class="breadcrumbs-inner">
            <div class="row m-0">
                <div class="col-sm-4">
                    <div class="page-header float-left">
                       
                    </div>
                </div>
                    <div class="col-sm-8">
                        <div class="page-header float-right">
                            <div class="page-title">
                                <ol class="breadcrumb text-right">
                                    <li><a href="#">Dashboard</a></li>
                                        <li><a href="#">Master</a></li>
                                        <li class="active">Add Events</li>
                                </ol>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
    </div>
    
<!--------------Add Event form--------------------->    
        <div class="content pb-0">
            <div class="row">
                <div class="col-lg-2"></div>
                     <div class="col-lg-8">
                        <div class="card">
                            <div class="card-header">Add Event</div>
                                <div class="card-body card-block">
                                    <form action="#" method="post" class="form-horizontal"enctype="multipart/form-data">
                                        <div class="row form-group">
                                            <div class="col col-md-12">
                                              	<label>Event Type</label>
                                          <select class="form-control"  value="eventtype" name="eventtype">
                                    	<option value="<?php echo $eventtype; ?>"><?php echo $eventtype; ?></option>

                                          <?php
                                         $sql= mysqli_query($db,"select type from event_type WHERE status=0");
                                while ($row = mysqli_fetch_array($sql)){?>
                              <option value="<?php echo $row['type'] ?>"><?php echo $row['type'] ?></option>
                                          <?php } ?>
                                        </select>
                                   
                        
                                          </div>
                                        </div>
                                            <div class="row form-group">
                                                <div class="col col-md-12">
                                                    <label for="company" class=" form-control-label">Event Name</label>
                                                        <input type="text" name="eventname" placeholder="Enter Event Name" class="form-control" value="<?php echo$eventname;?>">
                                                </div>
                                            </div>

                                            <div class="row form-group">
                                                <div class="col col-md-6">
                                                    <label for="company" class=" form-control-label">Event poster</label>
                                                    <input type="File" name="image" accept=".jpg,.png, .jpeg"  placeholder="Add Event Poster" class="form-control" value="<?php echo$image;?>">
                                                </div>
                                                 
                                                <div class="col col-md-6">
                                                    <label for="company" class=" form-control-label">Star Cast</label> 
                                                    <input type="text" name="starname" placeholder="star cast Name" class="form-control" value="<?php echo $starname;?>">
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-12">
                                                    <label for="company" class=" form-control-label">video link</label>
                                                        <input type="url" name="vlink"  placeholder="Enter video link" class="form-control" value="<?php echo$vlink;?>">
                                                </div>
                                            </div>
                                                 <div class="row form-group">
                                                <div class="col col-md-6">
                                                    	<label>Language Type</label>
                                            <select class="form-control " value="<?php echo$lang; ?>" name="language">
                                               	<option value="<?php echo $lang; ?>"><?php echo $lang; ?></option>
                                          <?php
                                         $sql= mysqli_query($db,"select language from language ORDER BY id");
                                while ($row = mysqli_fetch_array($sql)){?>
                              <option value="<?php echo $row['language'] ?>"><?php echo $row['language'] ?></option>
                                          <?php } ?>
                                        </select>
                                   </div>
                                                
                                                <div class="col col-md-6">
                                                    	<label>Dimention Type</label>
                                                   <select class="form-control " value="<?php echo$dimention; ?>" name="dimention">
                                             	<option value="<?php echo $dimention; ?>"><?php echo $dimention; ?></option>
                                          <?php
                                         $sql= mysqli_query($db,"select dimention  from show_type ORDER BY id");
                                while ($row = mysqli_fetch_array($sql)){?>
                              <option value="<?php echo $row['dimention'] ?>"><?php echo $row['dimention'] ?></option>
                                          <?php } ?>
                                        </select>
                                                </div>
                                            </div>
                                            
                                             <div class="row form-group">
                                                <div class="col col-md-6">
                                                    <label for="company" class=" form-control-label">Start Time</label>
                                                    
                                        
                                                    <input type="time"  class="form-control" ng-model="time" ng-change="ChangeTime()"
                                                    name="stime" value="<?php echo $stime;?>">
                                                </div>
                                                
                                                <div class="col col-md-6">
                                                    <label for="company" class=" form-control-label">End Time</label> 
                                                    <input type="time" class="form-control" ng-model="time" ng-change="ChangeTime()"
                                                    name="etime"  value="<?php echo $etime;?>">
                
                                                </div>
                                            </div>
            
                                                    <center>  <button type="submit" name="submit" class="btn btn-danger">Submit</button>
                                              <button type="update" name="update" class="btn btn-danger">Update</button>   </center>
                                    </form>
                        </div>
                </div>
            </div>
            
        </div> <!-- .content -->
        <!----------------------end of form---------------------------------------->
<!--------------------------footer start------------------------>
     <?php
       include('footer.php');
     ?> 
                            <?php

                        if (isset($_POST['submit'])) {
                      // receive all input values from the form
                                $eventtype=$_POST['eventtype'];
                                $eventname=$_POST['eventname'];
                              $stime=$_POST['stime'];
                               $etime=$_POST['etime'];
                             $starname=$_POST['starname'];
                    	$target_dir = "uploads/";
	$target_file = $target_dir . basename($_FILES["image"]["name"]);
		$uploadOk = 1;
		$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
		
		if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
			echo "The file ". basename( $_FILES["image"]["name"]). " has been uploaded.";
			} else {
			echo "Sorry, there was an error uploading your file.";
		}
		
	$image="https://www.minetechsoftwares.com/Shreyas/uploads/".$_FILES["image"]["name"];
	
	 $vlink=$_POST['vlink'];
	 $lang=$_POST['language'];
	 $dimention=$_POST['dimention'];
	

$query= mysqli_query($db,"INSERT INTO events(type,name,start_time,end_time,starcast,poster,videolink,language,dimentions) 
VALUES ('$eventtype','$eventname','$stime','$etime','$starname','$image','$vlink','$lang','$dimention')")or die(mysqli_error($query));
}
 if($query)
                                                           {
                                            echo "<script>alert('  Event  added Successfully........!');
                                            window.location='add_evnt.php';
                                            </script>";
                                            } 

?>


                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    