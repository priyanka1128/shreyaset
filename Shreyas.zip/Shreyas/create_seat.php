<?php
include('header.php');
include('connection.php');
session_start();
if($_SESSION["username"]==true)
{
 
}
else
{
	 header('location:index.php');
}
?>

<head> 
        <meta charset=utf-8 /> 
        
        <style type="text/css"> 
        
        .page{

  width: 50px;
  padding: 35px;
  border-spacing: 15px;
  margin: 10px;
  -webkit-column-gap: 150px; /* Chrome, Safari, Opera */
  -moz-column-gap: 200px; /* Firefox */
  column-gap: 100px; }
  .selected {background: coral;}
        </style>  
        </head>



<div class="breadcrumbs">
            <div class="breadcrumbs-inner">
                <div class="row m-0">
                    <div class="col-sm-4">
                        <div class="page-header float-left">
                           
                        </div>
                    </div>
                    <div class="col-sm-8">
                        <div class="page-header float-right">
                            <div class="page-title">
                                <ol class="breadcrumb text-right">
                                    <li><a href="#">Dashboard</a></li>
                                    <li><a href="#">Events</a></li>
                                    <li class="active">Create Seats</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
</div>

 


    <div class="content pb-0">
        <div class="row">
           <div class="col-lg-4"></div>
                <div class="col-lg-8">
                    
                                     
                                            <table id="myTable" class="page" border="1"id="bootstrap-data-table-export" class="table table-striped table-bordered"> 
                                            </table>
                                    		
                                    		<table id="myTable1" class="row1" border="1"> 
                                            </table> 
                                    		
                                    		<form>
                                            <input type="button" onclick="createTable()" value="Create the table"> 
                                            </form>
                                    		
                                    		
                                    		<form>
                                           <a href="seat_display.php">
                                    	  display structure
                                    		</a>	   
                                            </form>
                                    		
                                    		
                         
                                           	
                           
                </div>
            
        </div>      
    </div>
        



 
 
 
 <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>

<script>



function createTable()
{
	
rn = window.prompt("Input number of rows", 1);

cn = window.prompt("Input number of columns",1);
 
 
 
 for(var r=0;r<parseInt(rn,10);r++)  
  {
    
   var x=document.getElementById('myTable').insertRow(r);
   for(var c=0;c<parseInt(cn,10);c++)  
    {
		 
     var y=  x.insertCell(c);
	
     y.innerHTML=
	 "<img src=\'../Shreyas/images/armchair.png\' width=\'30px\' height=\'15px'><input class='coupon_question' type='checkbox' id='chair' value='' onclick='' />"+r+""+c;
	//seat(""+r+""+c);
	 
  }
 


    
   } 
   
   var ru=rn;
 
  var cu=cn;

  
  
    $.ajax({
        
        dataType: 'text',
        data: {'ru':ru,'cu':cu},
        method: "POST",
        url: 'insert.php',
        success: function (data) {
			//alert(data);

        },
        error: function (error) {
          return false;
        }
      });
  
 
}

/* function seat(r,c){
alert(""+r+"");	
} */



$(document).on('change', '[type=checkbox]', function (e) {
	/* var g= document.getElementById('chair');
	alert(g); */
	 $(this).closest('td').toggleClass('selected', this.checked);
if(this.checked==true){
	var rowIndex = $(this).closest('tr').index();
  var columnIndex = $(this).closest('td').index();
  alert(rowIndex+''+''+columnIndex);
 
  var rowI=rowIndex;
 
  var columnI=columnIndex;

  
  
    $.ajax({
        
        dataType: 'text',
        data: {'rowI':rowI,'columnI':columnI},
        method: "POST",
        url: 'insert1.php',
        success: function (data) {
		//	alert(data);

        },
        error: function (error) {
          return false;
        }
      });
  
  
}
else {
	alert(this.checked);
}

}).find(':checkbox').trigger('change');




</script>

   <?php
   include('footer.php');
   ?>
           
 