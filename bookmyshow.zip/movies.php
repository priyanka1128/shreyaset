<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">  
        <title>Shreyas Entertainment</title>
		<!-- Mobile Specific Meta
		================================================== -->
        <meta name="viewport" content="width=device-width, initial-scale=1">	
		<!-- Favicon -->
		<!-- <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png" /> -->
		<!-- CSS
		================================================== -->
		<!-- Fontawesome Icon font -->
		<link href="fontawesome-free-5.7.2-web/css/all.css" rel="stylesheet"> <!--load all styles -->
        <link rel="stylesheet" href="plugins/themefisher-font/style.css">
		<!-- bootstrap.min css -->
        <link rel="stylesheet" href="plugins/bootstrap/dist/css/bootstrap.min.css">
		<!-- Animate.css -->
        <link rel="stylesheet" href="plugins/animate-css/animate.css">
        <!-- Magnific popup css -->
        <link rel="stylesheet" href="plugins/magnific-popup/dist/magnific-popup.css">
		<!-- Slick Carousel -->
        <link rel="stylesheet" href="plugins/slick-carousel/slick/slick.css">
        <link rel="stylesheet" href="plugins/slick-carousel/slick/slick-theme.css">
		<!-- Main Stylesheet -->
        <link rel="stylesheet" href="css/style.css">		
    </head>
	
    <body id="body" data-spy="scroll" data-target=".navbar" data-offset="50">
	    <!-- Fixed Navigation -->
	<header id="navigation" class="navbar navigation">
    <div class="container">
		<!-- navbar-header starts here -->
        <div class="navbar-header">
            <!-- responsive nav button -->
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <!-- /responsive nav button -->
            <!-- logo -->
            <a class="navbar-brand logo" href="index.html">
            	<img src="images/sreyas.png">
            </a><!-- /logo -->
		</div>
		<!-- navbar-header end here -->
        <!-- main nav -->
        <nav class="collapse navbar-collapse navbar-left" role="Navigation">
            <ul id="nav" class="nav navbar-nav navigation-menu">
                <li><a data-scroll href="index.html">All</a></li>
				<li><a data-scroll href="movies.html">Movies</a></li>
				<li><a data-scroll href="events.html">Events</a></li>	
			</ul>
		</nav>
		<!-- main nav -->
		<!-- searchbar starts here-->
		<div class="row">
			<div class="col-md-4 col-md-offset-3">
				<form action="" class="search-form">
					<div class="form-group has-feedback">
						<label for="search" class="sr-only">Search</label>
						<input type="text" class="form-control" name="search" id="search" placeholder="search for movies & events">
						<span class="fa fa-search form-control-feedback"></span>
					</div>
				</form>
			</div>
		</div>
		<!-- searchbar ends here -->
		<!-- /main nav -->
		
	</div>
 	</header>
	<!--End Fixed Navigation-->

	<!--cards code start -->
<div class="container-fluid">	
		<div class="col-xs-12">
			<h1>Latest Movies</h1>
			<div class="carousel slide multi-item-carousel-movies" id="moviesCarousel">
			  <div class="carousel-inner">
				<div class="item active">
					  <div class="col-md-3"><a href="events.html"><img src="images/cards/lukachuppi.jpg" class="img-responsive">
					<p><strong></strong> </p></a></div>
				</div>
				<div class="item">
					<div class="col-md-3"><a href="events.html"><img src="images/cards/captainm.jpg" class="img-responsive"></a></div>
				</div>
				<div class="item">
					<div class="col-md-3"><a href="events.html"><img src="images/cards/ag.jpg" class="img-responsive"></a></div>
				</div>
				<div class="item">
					<div class="col-md-3"><a href="events.html"><img src="images/cards/cep.jpg" class="img-responsive"></a></div>
				</div>
				
			  </div>
			</div>
		</div>
	</div>
	<!--card code end-->
<!--footer code-->
<footer id="footer" class="bg-one">
	<div class="container">
		<div class="row wow fadeInUp" data-wow-duration="500ms">
			<div class="col-lg-12">
				<!-- Footer Social Links -->
				<div class="social-icon">
					<ul class="list-inline">
						<li><a href="#"><i class="tf-ion-social-facebook"></i></a></li>
						<li><a href="#"><i class="tf-ion-social-twitter"></i></a></li>
						<li><a href="#"><i class="tf-ion-social-google-outline"></i></a></li>
						<li><a href="#"><i class="tf-ion-social-youtube"></i></a></li>
						<li><a href="#"><i class="tf-ion-social-linkedin"></i></a></li>
					</ul>
				</div><!--/. End Footer Social Links -->
				<!-- copyright -->
			<div class="copyright text-center">
				<!-- <a href="index.html"><img src="images/shreyas.png"></a> -->
				<br />
				<p>Design And Developed by <a href="#">Morgat Softwares Pvt.Ltd</a>. Copyright &copy; <script>document.write(new Date().getFullYear())</script>. All Rights Reserved.</p>
			</div><!-- /copyright -->		
			</div> <!-- end col lg 12 -->
		</div> <!-- end row -->
	</div> <!-- end container -->
</footer> <!-- end footer -->

<!-- Essential Scripts-->
		
		<!-- Main jQuery -->
		<script type="text/javascript" src="plugins/jquery/dist/jquery.min.js"></script>
		<!-- Bootstrap 3.1 -->
		<script type="text/javascript" src="plugins/bootstrap/dist/js/bootstrap.min.js"></script>
		<!-- Slick Carousel -->
		<script type="text/javascript" src="plugins/slick-carousel/slick/slick.min.js"></script>
		<!-- Portfolio Filtering -->
		<script type="text/javascript" src="plugins/mixitup/dist/mixitup.min.js"></script>
		<!-- Smooth Scroll -->
		<script type="text/javascript" src="plugins/smooth-scroll/dist/js/smooth-scroll.min.js"></script>
		<!-- Magnific popup -->
		<script type="text/javascript" src="plugins/magnific-popup/dist/jquery.magnific-popup.min.js"></script>
		<!-- Google Map API -->
		<script type="text/javascript"  src="http://maps.google.com/maps/api/js?sensor=false"></script>
		<!-- Sticky Nav -->
		<script type="text/javascript" src="plugins/Sticky/jquery.sticky.js"></script>
		<!-- Number Counter Script -->
		<script type="text/javascript" src="plugins/count-to/jquery.countTo.js"></script>
		<!-- wow.min Script -->
		<script type="text/javascript" src="plugins/wow/dist/wow.min.js"></script>
		<!-- Custom js -->
		<script type="text/javascript" src="js/script.js"></script>
		
    </body>
</html>