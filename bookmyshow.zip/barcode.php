<?php
include('header.php');
?>



<!-----------------------------------------1st card----------------------------------------------------->
<div class="container-fluid">
    <div class="row">
        <div class="col-md-4">
            <div class="card mb-4"  style="margin-left:23px">
                <div class="row no-gutters">
                    <div class="col-md-4">
                        <img src="images/cards/aaa.jpg" class="card-img" alt="...">
                    </div>

                    <div class="col-md-6">
                        <div class="card-body" >
                            <h5 class="card-title">Infinity War</h5>
                            <p><strong  class="card-text">Sat.9 March 10PM </strong></p>
                            <p class="card-text"><strong class="text-muted">city pride: Mangala Cinema </strong></p>
                        </div>
                    </div>
                </div>

                <div class="xyz">
                    <hr><img src="images/cards/bar.png" id="input_img1">
                    <div class="col-md-6">
                        <h5 class="card-title">Screen 1</h5>
                        <p ><strong class="card-text">Gold-G22 G23 </strong></p>
                        <p  class="card-text"><strong class="text-muted">2 Tickets </strong></p>
                    </div>
            </div> 
        </div> 
</div> 

<!------------------------------------------------------2nd Card------------------------------------------------->
        <div class="col-md-4">
            <div class="card mb-4"  style="margin-left:23px">
                <div class="row no-gutters">
                    <div class="col-md-4">
                        <img src="images/cards/q.jpg" class="card-img" alt="...">
                    </div>

                    <div class="col-md-6">
                        <div class="card-body" >
                            <h5 class="card-title">Infinity War</h5>
                            <p><strong  class="card-text">Sat.9 March 10PM </strong></p>
                            <p class="card-text"><strong class="text-muted">city pride: Mangala Cinema </strong></p>
                        </div>
                    </div>
                </div>

                <div class="xyz">
                    <hr><img src="images/cards/bar.png" id="input_img1">
                    <div class="col-md-6">
                        <h5 class="card-title">Screen 2</h5>
                        <p ><strong class="card-text">Gold-G24 G25 </strong></p>
                        <p  class="card-text"><strong class="text-muted">3 Tickets </strong></p>
                    </div>
            </div> 
        </div>     
    </div>

<!-------------------------------------------3rd Card------------------------------------------------------>
    <div class="col-md-4">
            <div class="card mb-4"  style="margin-left:23px">
                <div class="row no-gutters">
                    <div class="col-md-4">
                        <img src="images/cards/aaa.jpg" class="card-img" alt="...">
                    </div>

                    <div class="col-md-6">
                        <div class="card-body" >
                            <h5 class="card-title">Infinity War</h5>
                            <p><strong  class="card-text">Sat.9 March 10PM </strong></p>
                            <p class="card-text"><strong class="text-muted">city pride: Mangala Cinema </strong></p>
                        </div>
                    </div>
                </div>

                <div class="xyz">
                    <hr><img src="images/cards/bar.png" id="input_img1">
                    <div class="col-md-6">
                        <h5 class="card-title">Screen 3</h5>
                        <p ><strong class="card-text">Gold-G26 G27 </strong></p>
                        <p  class="card-text"><strong class="text-muted">5 Tickets </strong></p>
                    </div>
                </div> 
            </div>     
        </div>
</div>
</div>

















<!-- <div class="container-fluid">	
			<div class="col-xs-12">
				<h1>Latest Events</h1>
				<div class="carousel slide multi-item-carousel-movies" id="moviesCarousel">
				  <div class="carousel-inner">
					<div class="item active">
                          <div class="col-md-3"><a href="index.php"><img src="images/cards/ab (1).jpg" class="img-responsive"></a><hr>
                      <div class="asd"><img src="images/cards/sr.png" id="input_img">
                      <p class="center" style="color:black"><strong>screen1</strong><br>
                       <strong> Gold-G22 G23 </strong><br> 
                       <strong> 2 Tickets </strong> </p>
                       
                        </div>
						</div>
					</div>
					<div class="item">
						<div class="col-md-3"><a href="index.php"><img src="images/cards/fd.jpg" class="img-responsive"></a></div>
					</div>
					<div class="item">
						<div class="col-md-3"><a href="index.php"><img src="images/cards/jk.jpg" class="img-responsive"></a></div>
					</div>
					<div class="item">
						<div class="col-md-3"><a href="index.php"><img src="images/cards/fd.jpg" class="img-responsive"></a></div>
					</div>
					
				  </div>
				</div>
			</div>
        </div> -->
        <?php
include('footer.php');
?>