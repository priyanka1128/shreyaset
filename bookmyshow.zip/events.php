
	<?php
include('header.php');
?>


<!--Card code start-->
		<div class="container-fluid">	
			<div class="col-xs-12">
				<h1>Latest Events</h1>
				<div class="carousel slide multi-item-carousel-movies" id="moviesCarousel">
				  <div class="carousel-inner">
					<div class="item active">
						  <div class="col-md-3"><a href="index.html"><img src="images/cards/ab (1).jpg" class="img-responsive">
						<p><strong></strong> </p></a></div>
					</div>
					<div class="item">
						<div class="col-md-3"><a href="index.html"><img src="images/cards/fd.jpg" class="img-responsive"></a></div>
					</div>
					<div class="item">
						<div class="col-md-3"><a href="index.html"><img src="images/cards/jk.jpg" class="img-responsive"></a></div>
					</div>
					<div class="item">
						<div class="col-md-3"><a href="index.html"><img src="images/cards/fd.jpg" class="img-responsive"></a></div>
					</div>
					
				  </div>
				</div>
			</div>
		</div>
		<!--card code end-->

		<?php
include('footer.php');
?>
</body>
</html>