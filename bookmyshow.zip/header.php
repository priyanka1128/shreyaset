<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">  
        <title>Shreyas Entertainment</title>
		<!-- Mobile Specific Meta
		================================================== -->
        <meta name="viewport" content="width=device-width, initial-scale=1">	
		<!-- Favicon -->
		<!-- <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png" /> -->
		<!-- CSS
		================================================== -->
		<!-- Fontawesome Icon font -->
		<link href="fontawesome-free-5.7.2-web/css/all.css" rel="stylesheet"> <!--load all styles -->
        <link rel="stylesheet" href="plugins/themefisher-font/style.css">
		<!-- bootstrap.min css -->
        <link rel="stylesheet" href="plugins/bootstrap/dist/css/bootstrap.min.css">
		<!-- Animate.css -->
        <link rel="stylesheet" href="plugins/animate-css/animate.css">
        <!-- Magnific popup css -->
        <link rel="stylesheet" href="plugins/magnific-popup/dist/magnific-popup.css">
		<!-- Slick Carousel -->
        <link rel="stylesheet" href="plugins/slick-carousel/slick/slick.css">
        <link rel="stylesheet" href="plugins/slick-carousel/slick/slick-theme.css">
		<!-- Main Stylesheet -->
		<link rel="stylesheet" href="css/style.css">	
		<!--javascript -->	
		<script type="text/javascript" src="js/megamenu.js"></script>
        <script>$(document).ready(function(){$(".megamenu").megamenu();});</script>
        <script type="text/javascript" src="js/jquery.leanModal.min.js"></script>
    </head>
	
    <body id="body" data-spy="scroll" data-target=".navbar" data-offset="50">
		
	<!-- Fixed Navigation -->
	<header id="navigation" class="navbar navigation">
    <div class="container">
		<!-- navbar-header starts here -->
        <div class="navbar-header">
            <!-- responsive nav button -->
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <!-- /responsive nav button -->
            <!-- logo -->
            <a class="navbar-brand logo" href="index.php">
							<img src="images/sreyas.png">

            </a><!-- /logo -->
		</div>
		<!-- navbar-header end here -->
        <!-- main nav -->
        <nav class="collapse navbar-collapse navbar-left" role="Navigation">
            <ul id="nav" class="nav navbar-nav navigation-menu">
                <li><a data-scroll href="index.php">All</a></li>
				<li><a data-scroll href="movies.php">Movies</a></li>
				<li><a data-scroll href="events.php">Events</a></li>
				<li><a data-scroll href="profile.php"><i class="fas fa-user-circle fa-2x" style="size:48px"></i></a></li>

					</ul>
		</nav>
		<!-- main nav -->
		<!-- searchbar starts here-->

		<button style="float:right" class="btn btn-primary" data-toggle="modal"  data-target="#myModal" >
			Login</button>

			
		<div class="row">
			<div class="col-md-4 col-md-offset-3">
				<form action="" class="search-form">
					<div class="form-group has-feedback">
						<label for="search" class="sr-only">Search</label>
						<input type="text" class="form-control" name="search" id="search" placeholder="search for movies & events">
						<span class="fa fa-search form-control-feedback"></span>
						</div>
				</form>
				</div>
		</div>


		<!-- searchbar ends here -->
		<!-- /main nav -->
		</div>
 	</header>
	<!--End Fixed Navigation-->
