<?php
include('header.php');
?>
<!DOCTYPE html>
<html>
<title>ABU TALHA</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  margin: auto;
  text-align: center;
	font-family: arial;
	background-color:lightgray;

}


.form-control {
    background-color: #white;
    background-color: white;
    border-radius: 0;
    padding: 5px 10px;
    border: 0 none;
    color: black;
}
</style>
</head>

<body>
<div class="card">
  
  <br>
 <div class="control">
   <input type="" class="form-control" value="You are in Pune"><a href=#  id="scr">Change</a>
</div>
<div class="control">
    <div class="label" >      </div>
   <input type="" class="form-control" value="Purchase History"/> <a href="#"><img src="images/cards/kj.png" id="input_img"></a>
</div>
<div class="control">
    <div class="label">  </div>
    <style>
       #input_img{
  position: absolute;
right: 5px;
width: 24px;
height: 26px;
margin-right: 602px;
margin-top: -29px;
color: black;
}
#scr{
	position: absolute;
right: 5px;
width: 20px;
height: 20px;
margin-right: 630px;
margin-top: -29px;
color: red;
}
    </style>
   <input type="text" class="form-control" value="Notification"> <a href="#">  <img src="images/cards/bell-icon.png" id="input_img"></a>
	 </div>
	 <br>
<div class="control">
    <div class="label"></div>
   <input type="text" class="form-control" value="QR Code"/><a href="barcode.php"><img src="images/cards/kk.png" id="input_img"></a>
</div>
   
    
</div>

</body>
</html>
	<!--card code end-->
	<?php
include('footer.php');
?>
<!-- Essential Scripts-->
		
		<!-- Main jQuery -->
		<script type="text/javascript" src="plugins/jquery/dist/jquery.min.js"></script>
		<!-- Bootstrap 3.1 -->
		<script type="text/javascript" src="plugins/bootstrap/dist/js/bootstrap.min.js"></script>
		<!-- Slick Carousel -->
		<script type="text/javascript" src="plugins/slick-carousel/slick/slick.min.js"></script>
		<!-- Portfolio Filtering -->
		<script type="text/javascript" src="plugins/mixitup/dist/mixitup.min.js"></script>
		<!-- Smooth Scroll -->
		<script type="text/javascript" src="plugins/smooth-scroll/dist/js/smooth-scroll.min.js"></script>
		<!-- Magnific popup -->
		<script type="text/javascript" src="plugins/magnific-popup/dist/jquery.magnific-popup.min.js"></script>
		<!-- Google Map API -->
		<script type="text/javascript"  src="http://maps.google.com/maps/api/js?sensor=false"></script>
		<!-- Sticky Nav -->
		<script type="text/javascript" src="plugins/Sticky/jquery.sticky.js"></script>
		<!-- Number Counter Script -->
		<script type="text/javascript" src="plugins/count-to/jquery.countTo.js"></script>
		<!-- wow.min Script -->
		<script type="text/javascript" src="plugins/wow/dist/wow.min.js"></script>
		<!-- Custom js -->
		<script type="text/javascript" src="js/script.js"></script>
		
    </body>
</html>